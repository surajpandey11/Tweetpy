This package used for cleaning tweets and represent them in standardize format.
This package contain 2 function one for cleaning your data and another for standardize your data.
For better output you have to give text column or only that variable that contain text otherwise it throws you error.